--
-- Tabla miembros
--

CREATE TABLE miembros (
    id serial NOT NULL,
    nombre character varying NOT NULL,
    email character varying,
    estatus character(1) DEFAULT 'A'::bpchar NOT NULL
);

ALTER TABLE ONLY miembros
    ADD CONSTRAINT miembros_id_key PRIMARY KEY (id);

--
-- Tabla sitios
--

CREATE TABLE sitios (
    id serial NOT NULL,
    nombre character varying NOT NULL,
    url character varying NOT NULL,
    notas text
);

ALTER TABLE ONLY sitios
    ADD CONSTRAINT sitios_id_key PRIMARY KEY (id);

--
-- Datos para la tabla miembros
--

INSERT INTO miembros (nombre, email, estatus) VALUES ('Daniel Becerril', 'daniel@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Roberto Ugarte', 'roberto@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Carlos Juarez', 'cj@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Elin Reynaldo Palma Aguirre', 'elin@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Carlos Rojas Mu&#241;oz', 'carlos@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Leonardo Ibarra Mor&#225;n', 'leonardo@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Alejandro B&#225;rcena Campos', 'alejandro@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Manuel Solis', 'smanuel@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Cesar Espino', 'rive@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Isaias Sanchez', 'hackervansan@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Luis Paez', 'lobogris@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Guillermo Valdez Lozano', 'guivaloz@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Fernando Flores R&#237;os', 'zeth-raven@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Oswaldo Aguilar aka awelo', 'oswaldo@gulag.org.mx', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Alejandro Arzola', 'alejandro.arzola@gmail.com', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Jorge Mart&#237;nez', 'jorgem@gmail.com', 'A');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Fulano de Tal', 'fulano@gmail.com', 'B');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Perengano de Tal', 'perengano@yahoo.com.mx', 'B');
INSERT INTO miembros (nombre, email, estatus) VALUES ('Sutanita de Tal', 'sutanita@msn.com.mx', 'B');

--
-- Datos para la tabla sitios
--

INSERT INTO sitios (nombre, url, notas) VALUES ('Cofrad&#237;a', 'http://www.cofradia.org/', 'Portal nacional de noticias sobre software libre y tecnolog&#237;a.');
INSERT INTO sitios (nombre, url, notas) VALUES ('Software Libre', 'http://www.softwarelibre.gob.mx', 'Portal del gobierno sobre software libre.');
INSERT INTO sitios (nombre, url, notas) VALUES ('OS News', 'http://www.osnews.com', 'Portal de noticias sobre sistemas operativos.');
INSERT INTO sitios (nombre, url, notas) VALUES ('Slashdot', 'http://slashdot.org/', 'Portal sobre software, tecnolog&#237;a y curiosidades.');

