<?php
	$titulo    = "Prueba con plantilla";
	$contenido = "Hola Mundo !";
	include('plantilla.php');
?>
