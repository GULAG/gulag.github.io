<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="author" content="Guillermo">
		<link title="Grey" href="inc/core.css" type="text/css" rel="stylesheet">
		<style type="text/css">
			body {
				font : 10px Verdana, Tahoma, Helvetica, sans-serif;
			}
		</style>
		<title><?php echo $titulo; ?></title>
	</head>
	<body>

		<!-- ENCABEZADO -->
		<div id="header">
			<div class="title"> GULAG </div>
		</div>
		<div class="bar-r"><span class="text"><?php echo date('d-m-Y'); ?></span></div>

		<!-- MENU -->
		<div id="menu">
			<h2 class="menu-title">» Menu</h2>
			<a title="OMG" href="objetos-home.php">+ home </a>
			<div class="submenu"><a title="OMG" href="objetos-miembros.php">  » Miembros </a>
				<div class="submenu"><a title="OMG" href="objetos-sitios.php">  » Sitios de Inter&eacute;s </a>
					<div class="submenu"><a title="OMG" href="objetos-gpl.php">  » Licencia GPL </a>
					</div>
				</div>
			</div>
		</div>

		<!-- CONTENIDO <span class="news-date"></span>  -->
		<div id="middle">
			<div class="content">
<?php
	if (is_array($contenido) && count($contenido)) {
		foreach ($contenido as $encabezado => $item) {
?>
				<h2 class="news-title"><?php echo $encabezado; ?></h2>
				<div class="news-body">
					<p>
<?php 
			if ((substr($item, -5) == '.html') || (substr($item, -4) == '.php')) {
				include('inc/'.$item);
			} else {
				echo $item;
			}
?>
					</p>
				</div>
<?php
		}
	} else {
?>
				<h2 class="news-title">Error</h2>
				<div class="news-body">
					<p>La varible contenido no esta definida correctamente.</p>
				</div>
<?php
	}
?>
			</div>

			<!-- PIE  -->
			<div id="footer">
				Dise&ntilde;o de la plantilla por &copy; <a href="http://www.sirbastian.com">Sirbastian manning</a> 2004 - 2005
			</div>
		</div>

	</body>
</html>
