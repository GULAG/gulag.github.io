<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Prueba con un formulario</title>
	</head>
	<body>
	<h2>Prueba con un formulario</h2>
<?php
	function muestra_formulario($nombre='', $edad='', $pasatiempos='') {
		$todos_los_pasatiempos = array('Cocina', 'Computación', 'Deportes', 'Viajar');
		if ($pasatiempos == '') {
			$pasatiempos = array();
		}
?>
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<table>
			<tr>
				<td>Nombre:</td>
				<td><input type="text" name="nombre" size="80" value="<?php echo $nombre; ?>"></td>
			</tr>
			<tr>
				<td>Edad:</td>
				<td><input type="text" name="edad" size="10" maxlength="3" value="<?php echo $edad; ?>"> a&ntilde;os</td>
			</tr>
			<tr>
				<td>Pasatiempos:</td>
				<td>
					<select multiple name="pasatiempos[]">
<?php
		foreach ($todos_los_pasatiempos as $p) {
			echo "<option";
			if (in_array($p, $pasatiempos)) {
				echo " selected";
			}
			echo ">$p</option>\n";
		}
?>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><button name="submit" value="enviar" type="submit">Enviar formulario</button></td>
			</tr>
		</table>
	</form>
<?php
	} // termina funcion muestra_formulario

	// BLOQUE PRINCIPAL
	if ($_SERVER['REQUEST_METHOD'] != 'POST') {
		// MOSTRAR FORMULARIO LIMPIO SI NO SE HA ENVIADO
		muestra_formulario();
	} else {
		if (empty($_POST['nombre']) || empty($_POST['edad']) || empty($_POST['pasatiempos'])) {
			// MENSAJE DE QUE FALTO POR LO MENOS UN CAMPO
			echo "<p><b>Le falta escribir por lo menos un campo del formulario. Corrija por favor.</b></p>\n";
			muestra_formulario($_POST['nombre'], $_POST['edad'], $_POST['pasatiempos']);
		} else {
			// MENSAJE DE QUE SE RECIBIO EL FORMULARIO SATISFACTORIAMENTE
?>
	<p><i>Gracias por dar sus datos</i></p>
	<table>
		<tr>
			<td>Nombre:</td>
			<td><b><?php echo $_POST['nombre']; ?></b></td>
		</tr>
		<tr>
			<td>Edad:</td>
			<td><b><?php echo $_POST['edad']; ?></b></td>
		</tr>
		<tr>
			<td>Pasatiempos:</td>
			<td><b><?php echo implode(', ', $_POST['pasatiempos']); ?></b></td>
		</tr>
	</table>
<?php
		}
	}
?>
	</body>
</html>
