<?php
/**
 * Ejemplo de sitio web usando programacion orientada a objetos
 */

/**
 * Miembros
 */
$titulo = "Miembros";

// Para sólo mostrar un mensaje, comente para habilitar el proceso
//$contenido = array('Miembros' => "Pendiente...");
//require_once('inc/plantilla.php');
//exit;

// Proceso
require_once('clases/listado_miembros.php');
$miembros = new Listado_Miembros();
try {
	$miembros->estatus = 'A';
	$miembros->consultar();
	$contenido['Miembros activos'] = $miembros->listado();
} catch (Exception $e) {
	$contenido['Error'] = $e->getMessage();
}

$inactivos = new Listado_Miembros();
try {
	$inactivos->estatus = 'B';
	$inactivos->consultar();
	$contenido['Miembros inactivos'] = $inactivos->listado();
} catch (Exception $e) {
	$contenido['Error'] = $e->getMessage();
}

require_once('inc/plantilla.php');

?>
