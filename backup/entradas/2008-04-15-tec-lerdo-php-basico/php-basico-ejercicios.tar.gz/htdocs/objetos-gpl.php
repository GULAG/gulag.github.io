<?php
/**
 * Ejemplo de sitio web usando programacion orientada a objetos
 */

/**
 * Licencia GPL
 */
$titulo = "Licencia GPL";

// Para sólo mostrar un mensaje, comente para habilitar el proceso
//$contenido = array('Licencia GPL' => "Pendiente...");
//require_once('inc/plantilla.php');
//exit;

// Mostrar la GPL
$contenido = array('Licencia GPL' => "licencia-publica-general.html");
require_once('inc/plantilla.php');

?>
