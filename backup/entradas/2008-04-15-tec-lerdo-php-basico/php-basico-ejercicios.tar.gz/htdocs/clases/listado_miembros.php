<?php
/**
 * Listado de Miembros
 *
 * @package Listados
 */

require_once('clases/base_datos.php');
require_once('clases/mostrar_listado.php');

/**
 * Clase Listado_Miembros
 *
 * @package Listados
 */
class Listado_Miembros {

	public $arreglo;
	public $estatus;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->arreglo = false;
		$this->estatus = 'A';
	} // constructor

	/**
	 * Consultar
	 * @return boolean
	 */
	public function consultar() {
		// VALIDAR ESTATUS
		if (($this->estatus != '') && ($this->estatus != 'A') && ($this->estatus != 'B')) {
			throw new Exception("<b>Error</b> Estatus incorrecto.");
		}
		// FILTRO
		if ($this->estatus != '') {
			$filtro_sql = "WHERE estatus = '$this->estatus'";
		}
		// CONSULTAR
		$base_datos = new BD_Motor();
		try {
			$consulta = $base_datos->comando("SELECT nombre, email, estatus 
				FROM miembros $filtro_sql ORDER BY nombre ASC");
		} catch (Exception $e) {
			throw new Exception("<b>Error:</b> Al consultar los miembros. ".$e->getMessage());
		}
		$this->arreglo = $consulta->obtener_todos_los_registros();
		// ENTREGAR VERDADERO
		return true;
	}

	/**
	 * Listado
	 * @return string html
	 */
	public function listado() {
		// VALIDAR QUE HAYA QUE MOSTRAR
		if ($this->arreglo === false) {
			return "<b>Error:</b> No se ha hecho la consulta.";
		} elseif (!count($this->arreglo)) {
			return "<b>Aviso:</b> La consulta no entregó resultados.";
		}
		// ELABORAR LISTADO
		$tabla              = new Mostrar_Listado();
		$tabla->encabezados = array('Nombre', 'e-mail', 'Estatus');
		$tabla->contenido   = $this->arreglo;
		// ENTREGAR
		return $tabla->html();
	}

} // clase Listado_Miembros

?>
