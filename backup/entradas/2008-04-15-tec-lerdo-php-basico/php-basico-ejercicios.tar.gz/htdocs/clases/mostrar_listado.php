<?php
/**
 * Mostrar listado
 *
 * @package Mostrar
 */

/**
 * Clase Mostrar_Listado
 *
 * @package Mostrar
 */
class Mostrar_Listado {

	public $encabezados;
	public $contenido;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->encabezados = false;
		$this->contenido   = false;
	} // constructor

	/**
	 * Entregar HTML
	 */
	public function html() {
		// VALIDAR
		if (!is_array($this->contenido) || !count($this->contenido)) {
			return "<b>Error:</b> El contenido es incorrecto.";
		} elseif (($this->encabezados !== false) && (!is_array($this->encabezados) || !count($this->encabezados))) {
			return "<b>Error:</b> Los encabezados son incorrectos.";
		}
		// ARMAR TABLA
		$s = "<table border=\"1\" cellspacing=\"0\" cellpadding=\"2\">\n";
		$s .= "<tr>";
		foreach ($this->encabezados as $enca) {
			$s .= "<th>$enca</th>";
		}
		$s .= "</tr>\n";
		foreach ($this->contenido as $registro) {
			$s .= "<tr>";
			foreach ($registro as $columna) {
				$s .= "<td>$columna</td>";
			}
			$s .= "</tr>\n";
		}
		$s .= "</table>\n";
		// ENTREGAR HTML
		return $s;
	} // html

} // clase Mostrar_Listado

?>
